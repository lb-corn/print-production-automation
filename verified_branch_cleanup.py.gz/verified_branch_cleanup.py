#!/usr/bin/env python3
"""One-off, static Git-object incident cleanup. Never checks out or runs project code.

Writes are limited to verified loader removal, no-content-change history merges,
and lease-protected removal of obsolete, merged, non-environment branches.
Unknown code, conflicts, protected refs, and application changes are retained.
"""
from __future__ import annotations
import base64
import collections
import datetime as dt
import functools
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

OWNERS = {'swartup-internal', 'gtcgrouplk', 'affixientllc', 'fyxtr', 'lb-corn', 'cleansense'}
TOOL_PREFIX = 'security/verified-cleanup-20261027'
SOURCE_BRANCH = 'security/incident-cleanup-runner-20261027'
MAX_BLOB = 8 * 1024 * 1024
BAD_BLOBS = {
    '2319b5791fc95852eb1fab78ceba3aa96ca7a74d',
    '38ba99d7bb27fdeb45b82c6fdffe8ecca03108bb',
    '31ce18eddf4c96c1a705dbceaec4304f953d4dc3',
}
Y7 = re.compile(rb'\bfunction\s+y7\s*\(\s*R\s*,\s*c\s*,\s*e\s*,\s*r\s*,\s*t\s*,\s*i\s*,\s*s\b')
GLOBAL_MARK = re.compile(rb'global\s*\[\s*[\x22\x27]![' + b'\x22\x27' + rb']\s*\]\s*=')
FONT_EXTS = {'.ttf', '.otf', '.woff', '.woff2', '.llf', '.lfk'}
FONT_MAGIC = (b'\x00\x01\x00\x00', b'OTTO', b'wOFF', b'wOF2', b'ttcf', b'true')
JS_BODY = re.compile(rb'(?:\bfunction\s+\w+\s*\(|\brequire\s*\(|\b(?:eval|Function)\s*\(|\bchild_process\b|global\s*\[)')
TASK_FONT = re.compile(r'\bnode(?:\.exe)?\s+(?:--?[\w-]+(?:=\S+)?\s+)*[\"\x27]?(?:[^\s\"\x27;&|]+\.(?:ttf|otf|woff2?|llf|lfk))(?=[\"\x27\s;&|]|$)', re.I)
NODE_API = re.compile(r'\bnode(?:\.exe)?\s+[\"\x27]?(?:\./)?api\.js[\"\x27]?(?=\s|$|[;&|])', re.I)
ENV_BRANCH = re.compile(r'^(?:main|master|develop|development|dev|stage|staging|production|prod|qa|uat|release|releases)(?:$|[/_-])', re.I)
UNCHANGED = object()


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def jsonc(text: str):
    """Remove comments and trailing commas only outside JSON strings."""
    s = text.lstrip('\ufeff'); out = []; i = 0; quoted = False; escaped = False
    while i < len(s):
        c = s[i]
        if quoted:
            out.append(c)
            if escaped: escaped = False
            elif c == '\\': escaped = True
            elif c == '"': quoted = False
            i += 1; continue
        if c == '"': quoted = True; out.append(c); i += 1; continue
        if s[i:i+2] == '//':
            end = s.find('\n', i + 2); i = len(s) if end < 0 else end; continue
        if s[i:i+2] == '/*':
            end = s.find('*/', i + 2)
            if end < 0: raise ValueError('unterminated JSON comment')
            out.append(' '); i = end + 2; continue
        out.append(c); i += 1
    s = ''.join(out); out = []; i = 0; quoted = False; escaped = False
    while i < len(s):
        c = s[i]
        if quoted:
            out.append(c)
            if escaped: escaped = False
            elif c == '\\': escaped = True
            elif c == '"': quoted = False
        elif c == '"': quoted = True; out.append(c)
        elif c == ',':
            j = i + 1
            while j < len(s) and s[j].isspace(): j += 1
            if j >= len(s) or s[j] not in '}]': out.append(c)
        else: out.append(c)
        i += 1
    return json.loads(''.join(out))


def dump_json(obj) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def loader(data: bytes) -> bool:
    return bool(Y7.search(data) and (GLOBAL_MARK.search(data) or b'\\u006C\\u0065\\u006E' in data) and len(data) > 3000)


def classify(path: str, sha: str, data: bytes):
    """Returns replacement (UNCHANGED / None=delete / bytes), findings, notes."""
    p = PurePosixPath(path); name = p.name.lower(); ext = p.suffix.lower()
    findings = []; notes = []
    if sha in BAD_BLOBS:
        return None, ['confirmed:exact-known-malware-blob'], notes
    is_loader = loader(data)
    if ext in FONT_EXTS and not data.startswith(FONT_MAGIC):
        if is_loader or (JS_BODY.search(data[:262144]) and b'\0' not in data[:4096] and (b'require' in data or b'eval' in data or b'global' in data)):
            return None, ['confirmed:javascript-disguised-as-font'], notes
        if name in {'fa-solid-300.llf', 'fa-solid.lfk', 'fa-solid-500.woff2'}:
            findings.append('review:invalid-font-with-known-indicator-name')
    if name == 'api.js' and is_loader:
        match = Y7.search(data)
        prefix = data[:match.start()].strip() if match else data
        if not prefix or (GLOBAL_MARK.match(prefix) and len(prefix) < 180):
            return None, ['confirmed:standalone-obfuscated-api-loader'], notes
        findings.append('confirmed:loader-in-api-needs-prefix-review')
    is_postcss = name.startswith('postcss.config.') or name in {'.postcssrc.js', '.postcssrc.cjs', '.postcssrc.mjs'}
    if is_postcss and is_loader:
        marks = [m.start() for m in [GLOBAL_MARK.search(data), Y7.search(data)] if m]
        cut = min(marks); clean = data[:cut].rstrip() + b'\n'
        if re.search(rb'\bexport\s+default\b|\bmodule\.exports\b', clean):
            import_line = re.compile(rb'(?m)^import\s*\{\s*createRequire\s*\}\s*from\s*[\x22\x27](?:node:)?module[\x22\x27];\s*\n')
            require_line = re.compile(rb'(?m)^const\s+require\s*=\s*createRequire\(import\.meta\.url\);\s*\n')
            candidate = import_line.sub(b'', require_line.sub(b'', clean))
            if not re.search(rb'\brequire\b|\bcreateRequire\b', candidate): clean = candidate
            if not loader(clean):
                return clean, ['confirmed:appended-obfuscated-postcss-loader'], notes
        findings.append('confirmed:postcss-loader-needs-prefix-review')
    is_task = path == '.vscode/tasks.json' or path.endswith('/.vscode/tasks.json') or name.endswith('.code-workspace')
    if is_task:
        try:
            obj = jsonc(data.decode('utf-8-sig'))
            container = obj.get('tasks') if name.endswith('.code-workspace') else obj
            tasks = container.get('tasks', []) if isinstance(container, dict) else []
            retained = []; removed = 0
            if not isinstance(tasks, list): raise ValueError('tasks is not an array')
            for task in tasks:
                if not isinstance(task, dict): retained.append(task); continue
                pieces = [task.get('command', '')] + task.get('args', []) if isinstance(task.get('args', []), list) else [task.get('command', '')]
                command = ' '.join(x for x in pieces if isinstance(x, str))
                if TASK_FONT.search(command):
                    removed += 1; continue
                retained.append(task)
                if isinstance(task.get('runOptions'), dict) and task['runOptions'].get('runOn') == 'folderOpen':
                    notes.append('review:remaining-folderOpen-task-not-proven-malicious')
            if removed:
                container['tasks'] = retained
                if not retained and not name.endswith('.code-workspace') and set(obj) <= {'version', 'tasks'}:
                    return None, ['confirmed:font-executing-vscode-task'], notes
                return dump_json(obj), ['confirmed:font-executing-vscode-task'], notes
        except (ValueError, TypeError, AttributeError, UnicodeError):
            if b'folderOpen' in data or b'fa-solid' in data:
                findings.append('review:unparsed-vscode-task')
    if is_loader and not findings:
        findings.append('confirmed:known-loader-signature-outside-auto-remediation')
    if is_postcss and not is_loader and re.search(rb'\b(?:eval|Function)\s*\(|\bchild_process\b|(?:\\u00[0-9A-Fa-f]{2}){12}', data):
        findings.append('review:unexpected-executable-postcss-configuration')
    if path.startswith('.github/workflows/'):
        if re.search(rb'(?m)^\s*(?:pull_request_target|workflow_run)\s*:', data):
            notes.append('review:privileged-or-chained-workflow-trigger')
        if re.search(rb'(?:curl|wget)[^\n]{0,500}\|\s*(?:bash|sh)\b', data):
            notes.append('review:workflow-download-and-execute')
    return UNCHANGED, findings, notes


def clean_package(data: bytes, can_remove_api: bool):
    findings = []; changed = False
    try:
        obj = json.loads(data.decode('utf-8-sig')); scripts = obj.get('scripts', {})
        if not isinstance(scripts, dict): return UNCHANGED, ['review:invalid-npm-scripts']
        for key, value in list(scripts.items()):
            if not isinstance(value, str) or not NODE_API.search(value): continue
            if not can_remove_api:
                findings.append('review:api-loader-hook-without-proven-malicious-target:' + key); continue
            cleaned = re.sub(r'^\s*node(?:\.exe)?\s+[\"\x27]?(?:\./)?api\.js[\"\x27]?\s*&&\s*', '', value, flags=re.I)
            cleaned = re.sub(r'\s*&&\s*node(?:\.exe)?\s+[\"\x27]?(?:\./)?api\.js[\"\x27]?\s*$', '', cleaned, flags=re.I)
            if re.fullmatch(r'\s*node(?:\.exe)?\s+[\"\x27]?(?:\./)?api\.js[\"\x27]?\s*', cleaned, re.I):
                del scripts[key]; changed = True
                findings.append('confirmed:removed-standalone-api-npm-hook:' + key)
            elif cleaned != value and not NODE_API.search(cleaned):
                scripts[key] = cleaned; changed = True
                findings.append('confirmed:removed-api-npm-prefix:' + key)
            else:
                findings.append('review:complex-api-npm-hook:' + key)
        return (dump_json(obj) if changed else UNCHANGED), findings
    except (ValueError, UnicodeError, AttributeError, TypeError):
        if b'api.js' in data: findings.append('review:unparsed-package-with-api-hook')
        return UNCHANGED, findings


class Cleanup:
    def __init__(self, root: Path, repo: str, token: str):
        self.root = root; self.repo = repo; self.token = token
        self.api = 'https://api.github.com/repos/' + repo
        self.env = os.environ.copy()
        for k in list(self.env):
            if k.startswith('GIT_') or k in {'SSH_ASKPASS', 'GIT_ASKPASS'}: self.env.pop(k, None)
        self.env.update({'GIT_CONFIG_NOSYSTEM':'1', 'GIT_CONFIG_SYSTEM':'/dev/null', 'GIT_CONFIG_GLOBAL':'/dev/null',
                         'GIT_TERMINAL_PROMPT':'0', 'GIT_ALLOW_PROTOCOL':'https', 'GIT_AUTHOR_NAME':'GitHub Security Cleanup',
                         'GIT_AUTHOR_EMAIL':'41898282+github-actions[bot]@users.noreply.github.com',
                         'GIT_COMMITTER_NAME':'GitHub Security Cleanup', 'GIT_COMMITTER_EMAIL':'41898282+github-actions[bot]@users.noreply.github.com'})
        settings = {'core.hooksPath':'/dev/null', 'core.fsmonitor':'false', 'commit.gpgsign':'false',
                    'merge.renormalize':'false', 'core.attributesfile':'/dev/null', 'credential.helper':''}
        if token:
            settings['http.https://github.com/.extraheader'] = 'AUTHORIZATION: basic ' + base64.b64encode(('x-access-token:' + token).encode()).decode()
        self.env['GIT_CONFIG_COUNT'] = str(len(settings))
        for i, (k, v) in enumerate(settings.items()): self.env[f'GIT_CONFIG_KEY_{i}'] = k; self.env[f'GIT_CONFIG_VALUE_{i}'] = v
        self.record = {'repository':repo, 'started_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
                       'method':'bare Git objects; no checkout, dependency install, hooks or application execution',
                       'scope':'all accessible branch tips; known-indicator static content scan; history/tags/LFS/submodules not certified',
                       'branches':[], 'merges':[], 'deleted_branches':[], 'errors':[], 'limits':{'max_blob_bytes':MAX_BLOB}}
        self.cache = {}; self.cache_bytes = 0; self.large_cache = {}

    def git(self, *args, data=None, extra=None, check=True):
        env = self.env if not extra else dict(self.env, **extra)
        proc = subprocess.run(['git', *args], cwd=self.root, env=env, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=240)
        if check and proc.returncode:
            err = proc.stderr.decode('utf-8', 'replace')[-3000:]
            if self.token: err = err.replace(self.token, '[REDACTED]')
            raise RuntimeError(f'git {args[0]} failed ({proc.returncode}): {err}')
        return proc

    def text(self, *args, **kw): return self.git(*args, **kw).stdout.decode('utf-8', 'surrogateescape').strip()

    def request(self, path):
        req = urllib.request.Request(self.api + path, headers={'Accept':'application/vnd.github+json',
             'Authorization':'Bearer ' + self.token, 'X-GitHub-Api-Version':'2022-11-28', 'User-Agent':'Verified-Static-Incident-Cleanup'})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=40) as response: return json.load(response)
            except urllib.error.HTTPError as e:
                if e.code not in {429,500,502,503,504} or attempt == 3: raise
                time.sleep(2 ** attempt)
        raise RuntimeError('API retry exhausted')

    def heads(self):
        result = {}
        for line in self.text('ls-remote', '--heads', 'origin').splitlines():
            sha, ref = line.split('\t', 1); result[ref.removeprefix('refs/heads/')] = sha
        return result

    def blob(self, sha):
        if sha not in self.cache:
            raw = self.git('cat-file', 'blob', sha).stdout
            if len(raw) <= 262144 and self.cache_bytes + len(raw) <= 128*1024*1024:
                self.cache[sha] = raw; self.cache_bytes += len(raw)
            else: return raw
        return self.cache[sha]

    def scan_large(self, sha):
        if sha in self.large_cache: return self.large_cache[sha]
        proc = subprocess.Popen(['git','cat-file','blob',sha],cwd=self.root,env=self.env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        carry = b''; has_y7 = False; has_marker = False
        try:
            while True:
                chunk = proc.stdout.read(1024*1024)
                if not chunk: break
                block = carry + chunk
                has_y7 = has_y7 or bool(Y7.search(block))
                has_marker = has_marker or bool(GLOBAL_MARK.search(block)) or b'\\u006C\\u0065\\u006E' in block
                carry = block[-4096:]
            err = proc.stderr.read(); rc = proc.wait(timeout=30)
            if rc: raise RuntimeError('large blob read failed: '+err.decode('utf-8','replace')[-500:])
        finally:
            if proc.poll() is None: proc.kill(); proc.wait()
        result = bool(has_y7 and has_marker)
        self.large_cache[sha] = result
        return result

    def entries(self, sha):
        out = {}
        for raw in self.git('ls-tree', '-r', '-l', '-z', '--full-tree', sha).stdout.split(b'\0'):
            if not raw: continue
            meta, path = raw.split(b'\t', 1); mode, kind, blob, size = meta.split()
            path = path.decode('utf-8', 'surrogateescape')
            out[path] = {'mode':mode.decode(), 'type':kind.decode(), 'sha':blob.decode(), 'size':int(size) if size != b'-' else None}
        return out

    def scan(self, sha):
        entries = self.entries(sha); patches = {}; findings = []; notes = []; skipped = []; count = 0
        for path, ent in entries.items():
            if ent['type'] != 'blob': skipped.append({'path':path,'reason':'submodule-not-followed'}); continue
            if ent['size'] > MAX_BLOB:
                try:
                    if self.scan_large(ent['sha']): findings.append({'path':path,'blob_sha':ent['sha'],'reason':'confirmed:loader-in-large-blob-needs-review','automatically_remediable':False})
                    count += 1
                    if PurePosixPath(path).name.lower() in {'package.json','tasks.json'} or 'postcss.config.' in PurePosixPath(path).name.lower():
                        skipped.append({'path':path,'reason':'oversize-sensitive-config-not-parsed','bytes':ent['size']})
                except Exception as e: skipped.append({'path':path,'reason':'large-blob-read-error','error':str(e)})
                continue
            try: raw = self.blob(ent['sha'])
            except Exception as e: skipped.append({'path':path,'reason':'blob-read-error','error':str(e)}); continue
            count += 1
            if raw.startswith(b'version https://git-lfs.github.com/spec/v1'):
                skipped.append({'path':path,'reason':'git-lfs-content-not-fetched'}); continue
            replacement, fs, ns = classify(path, ent['sha'], raw)
            if replacement is not UNCHANGED: patches[path] = replacement
            for reason in fs: findings.append({'path':path,'blob_sha':ent['sha'],'reason':reason,'automatically_remediable':replacement is not UNCHANGED})
            for reason in ns: notes.append({'path':path,'reason':reason})
        for path, ent in entries.items():
            if PurePosixPath(path).name != 'package.json' or ent['type'] != 'blob' or ent['size'] > MAX_BLOB: continue
            target = str(PurePosixPath(path).parent / 'api.js')
            can_remove = target in patches and patches[target] is None
            replacement, fs = clean_package(self.blob(ent['sha']), can_remove)
            if replacement is not UNCHANGED: patches[path] = replacement
            for reason in fs: findings.append({'path':path,'blob_sha':ent['sha'],'reason':reason,'automatically_remediable':reason.startswith('confirmed:') and replacement is not UNCHANGED})
        return entries, patches, {'files_read':count,'findings':findings,'review_notes':notes,'coverage_gaps':skipped}

    def make_commit(self, parent, entries, patches):
        index = str(self.root / ('index-' + parent))
        extra = {'GIT_INDEX_FILE':index}
        try:
            self.git('read-tree', parent, extra=extra)
            for path, replacement in sorted(patches.items()):
                if replacement is None: self.git('update-index', '-z', '--index-info', data=b'0 '+b'0'*40+b'\t'+path.encode('utf-8','surrogateescape')+b'\0', extra=extra)
                else:
                    blob = self.text('hash-object', '-w', '--stdin', data=replacement)
                    self.git('update-index', '--add', '--cacheinfo', entries[path]['mode'], blob, path, extra=extra)
            tree = self.text('write-tree', extra=extra)
            message = b'security: remove verified malicious loaders and execution hooks [skip ci]\n\nStatic Git-object cleanup only. No project code executed. Application changes retained; no history rewritten.\n'
            return self.text('commit-tree', tree, '-p', parent, data=message)
        finally:
            try: Path(index).unlink()
            except FileNotFoundError: pass

    def advance(self, branch, before, after):
        current = self.heads().get(branch)
        if current != before: raise RuntimeError('branch changed concurrently; no update: ' + branch)
        self.git('push', '--porcelain', 'origin', after + ':refs/heads/' + branch)
        if self.heads().get(branch) != after: raise RuntimeError('post-push branch verification failed: ' + branch)

    def obsolete_delete(self, branch, sha, main_sha, open_refs):
        if branch == self.default or ENV_BRANCH.search(branch) or branch.startswith(TOOL_PREFIX) or branch == SOURCE_BRANCH: return False
        if branch in open_refs: return False
        if self.git('merge-base','--is-ancestor',sha,main_sha,check=False).returncode: return False
        if self.heads().get(branch) != sha: return False
        # Lease protects the exact ref being deleted. No surviving ref is force-updated.
        self.git('push','--porcelain','--force-with-lease=refs/heads/'+branch+':'+sha,'origin',':refs/heads/'+branch)
        if branch in self.heads(): raise RuntimeError('deletion verification failed: ' + branch)
        self.record['deleted_branches'].append({'branch':branch,'last_sha':sha,'reason':'all commits reachable from default; no open PR reference; non-environment branch'})
        return True

    def run(self):
        metadata = self.request(''); self.default = metadata['default_branch']; self.record['default_branch'] = self.default
        self.git('init','--bare','.')
        self.git('remote','add','origin','https://github.com/'+self.repo+'.git')
        self.git('fetch','--no-tags','origin','+refs/heads/*:refs/remotes/origin/*')
        heads = self.heads(); self.record['initial_heads'] = heads
        original = {b:s for b,s in heads.items() if not b.startswith(TOOL_PREFIX) and b != SOURCE_BRANCH}
        open_refs = set(); prs = []
        for page in range(1,101):
            batch = self.request('/pulls?state=open&per_page=100&page='+str(page)); prs.extend(batch)
            if len(batch)<100: break
        else: raise RuntimeError('pull-request pagination incomplete')
        for p in prs:
            open_refs.add(p['base']['ref'])
            if p.get('head',{}).get('repo',{}).get('full_name') == self.repo: open_refs.add(p['head']['ref'])
        self.record['open_pull_requests'] = [{'number':p['number'],'head':p['head']['ref'],'base':p['base']['ref']} for p in prs]
        state = {}; blocked = set()
        for branch in sorted(original, key=lambda b:(b!=self.default,b)):
            sha = original[branch]
            rec = {'branch':branch,'before_sha':sha,'after_sha':sha,'changes':[]}
            try:
                entries, patches, scan = self.scan(sha); rec['before_scan'] = scan
                if patches:
                    after = self.make_commit(sha,entries,patches)
                    _, again, check = self.scan(after)
                    if again: raise RuntimeError('sanitizer is not idempotent; no branch update')
                    self.advance(branch,sha,after); rec['after_sha'] = after; rec['after_scan'] = check
                    for path,replacement in sorted(patches.items()):
                        rec['changes'].append({'path':path,'action':'delete' if replacement is None else 'replace','before_blob':entries[path]['sha'],
                                               'after_blob':None if replacement is None else git_blob_sha(replacement)})
                else: rec['after_scan'] = scan
                state[branch] = rec['after_sha']
                if rec['after_scan']['findings'] or rec['after_scan']['coverage_gaps']: blocked.add(branch)
            except Exception as e:
                rec['error'] = str(e); self.record['errors'].append({'branch':branch,'error':str(e)}); blocked.add(branch)
                state[branch] = self.heads().get(branch,sha)
            self.record['branches'].append(rec)
            print('BRANCH_RESULT '+json.dumps({'branch':branch,'changes':len(rec['changes']),'remaining_findings':len(rec.get('after_scan',{}).get('findings',[])),
                  'coverage_gaps':len(rec.get('after_scan',{}).get('coverage_gaps',[])),'error':rec.get('error')},ensure_ascii=True),flush=True)
        main = state[self.default]
        for branch,sha in list(sorted(state.items())):
            if branch == self.default or branch in blocked or self.default in blocked: continue
            try:
                if self.git('merge-base','--is-ancestor',sha,main,check=False).returncode == 0:
                    self.obsolete_delete(branch,sha,main,open_refs); continue
                # Built-in merge computation only, in a bare repo with hooks and user config disabled.
                merge = self.git('merge-tree','--write-tree',main,sha,check=False)
                first = merge.stdout.splitlines()[0].decode('ascii','ignore') if merge.stdout else ''
                if merge.returncode or not re.fullmatch('[0-9a-f]{40}',first):
                    self.record['merges'].append({'branch':branch,'status':'retained-merge-conflict-or-unrelated-history'}); continue
                main_tree = self.text('rev-parse',main+'^{tree}')
                if first != main_tree:
                    changed = self.git('diff','--no-ext-diff','--no-textconv','--name-only','-z',main,first).stdout.split(b'\0')
                    self.record['merges'].append({'branch':branch,'status':'retained-application-or-configuration-diff-needs-review',
                        'changed_paths':[x.decode('utf-8','surrogateescape') for x in changed if x]}); continue
                merged = self.text('commit-tree',main_tree,'-p',main,'-p',sha,
                    data=('security: integrate cleaned obsolete branch without changing files [skip ci]\n\nBranch: '+branch+'\nVerified merged tree is byte-identical to current default.\n').encode())
                self.advance(self.default,main,merged)
                self.record['merges'].append({'branch':branch,'status':'merged-no-content-change','commit':merged,'previous_default_sha':main})
                main = merged; state[self.default] = main
                self.obsolete_delete(branch,sha,main,open_refs)
            except Exception as e: self.record['errors'].append({'branch':branch,'stage':'merge-or-delete','error':str(e)})
        self.git('fetch','--prune','--no-tags','origin','+refs/heads/*:refs/remotes/origin/*')
        final = self.heads(); self.record['final_heads'] = final; final_scans = []
        for branch,sha in sorted(final.items()):
            if branch.startswith(TOOL_PREFIX) or branch == SOURCE_BRANCH: continue
            try:
                _, patches, scan = self.scan(sha)
                final_scans.append({'branch':branch,'sha':sha,'files_read':scan['files_read'],'findings':scan['findings'],
                                    'review_notes':scan['review_notes'],'coverage_gaps':scan['coverage_gaps'],'repairable_residue':sorted(patches)})
            except Exception as e: final_scans.append({'branch':branch,'sha':sha,'error':str(e)})
        self.record['final_scans'] = final_scans
        self.record['summary'] = {'original_branches':len(original),'remaining_original_branches':len(final_scans),
            'branches_patched':sum(bool(r['changes']) for r in self.record['branches']),
            'files_changed_across_branches':sum(len(r['changes']) for r in self.record['branches']),
            'no_content_change_merges':sum(r['status']=='merged-no-content-change' for r in self.record['merges']),
            'branches_deleted':len(self.record['deleted_branches']),
            'remaining_findings':sum(len(r.get('findings',[])) for r in final_scans),
            'coverage_gaps':sum(len(r.get('coverage_gaps',[])) for r in final_scans),
            'errors':len(self.record['errors'])+sum('error' in r for r in final_scans),
            'all_surviving_branch_tips_pass_known_indicator_scan':bool(final_scans) and not self.record['errors'] and all(not r.get('error') and not r.get('findings') and not r.get('coverage_gaps') for r in final_scans),
            'not_a_guarantee_of_absence_of_unknown_malware':True}
        self.record['completed_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        return self.record


def main():
    repo = os.environ.get('GITHUB_REPOSITORY',''); token = os.environ.get('GITHUB_TOKEN','')
    if repo.count('/') != 1 or repo.split('/')[0] not in OWNERS or repo.split('/')[1] == 'who-frontline-ai':
        raise SystemExit('Repository outside authorized scope')
    if not token: raise SystemExit('Missing repository-scoped GITHUB_TOKEN')
    if not os.environ.get('GITHUB_REF','').startswith('refs/heads/'+TOOL_PREFIX):
        raise SystemExit('Not running on the isolated one-off cleanup branch')
    output = Path(os.environ.get('RUNNER_TEMP', tempfile.gettempdir())) / 'verified-cleanup-report.json'
    with tempfile.TemporaryDirectory(prefix='static-git-cleanup-') as td:
        worker = Cleanup(Path(td),repo,token)
        try: report = worker.run()
        except Exception as e:
            worker.record['fatal_error'] = str(e).replace(token,'[REDACTED]'); report = worker.record
        output.write_text(json.dumps(report,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
        print('CLEANUP_REPORT_PATH '+str(output))
        print('CLEANUP_SUMMARY '+json.dumps(report.get('summary',{'fatal_error':report.get('fatal_error')}),ensure_ascii=True))
        print('CLEANUP_REPORT_JSON '+json.dumps(report,ensure_ascii=True,separators=(',',':')))
        summary = os.environ.get('GITHUB_STEP_SUMMARY')
        if summary:
            with open(summary,'a',encoding='utf-8') as f:
                f.write('## Verified static incident cleanup\n\nNo repository application code executed. No history rewrite.\n\n```json\n'+json.dumps(report.get('summary',{}),indent=2)+'\n```\n')
        if report.get('fatal_error'): raise SystemExit(1)

if __name__ == '__main__': main()
